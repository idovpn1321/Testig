#!/system/bin/sh
mkdir -p /data/local/tmp/imm
chmod 755 /data/local/tmp/imm