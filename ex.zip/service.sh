#!/system/bin/sh

# Intelligent Memory Manager - Main Service
# Author: YourName
# Version: 1.0

MODPATH=${0%/*}
DATAPATH="/data/local/tmp/imm"
LOG="$DATAPATH/debug.log"
PATTERN_DB="$DATAPATH/app_patterns.db"
CONFIG="$DATAPATH/config"
$MODPATH/bin/memory_monitor status | grep "MEM_AVAILABLE"
PREDICTED_APPS=$($MODPATH/bin/pattern_analyzer predict)

# Send notification
send_notification() {
    local title="$1"
    local message="$2"
    local priority="${3:-0}"  # -2 to 2
    local id="${4:-imm_$(date +%s)}"
    
    # Use cmd notification command (Android 8+)
    cmd notification post -S bigtext -t "$title" "$id" "$message" >/dev/null 2>&1
    
    # Fallback using am broadcast
    if [ $? -ne 0 ]; then
        am broadcast -a android.intent.action.NOTIFICATION \
            --es title "$title" \
            --es message "$message" \
            --ei priority "$priority" >/dev/null 2>&1
    fi
}

# Initialize logging
init_logging() {
    mkdir -p "$DATAPATH"
    chmod 755 "$DATAPATH"
    echo "$(date '+%Y-%m-%d %H:%M:%S'): IMM Service Started" >> "$LOG"
    
    # Startup notification
    send_notification "IMM Service Started" "Intelligent Memory Manager is now active" 0 "imm_startup"
}

# Memory fragmentation check
check_memory_fragmentation() {
    local frag_info=$(cat /proc/buddyinfo 2>/dev/null)
    local order_0=$(echo "$frag_info" | awk '{print $5}' | head -1)
    local order_3=$(echo "$frag_info" | awk '{print $8}' | head -1)
    
    # Calculate fragmentation ratio
    if [ "$order_0" -gt 0 ] && [ "$order_3" -gt 0 ]; then
        local ratio=$((order_0 / order_3))
        echo "$ratio"
    else
        echo "0"
    fi
}

# Trigger memory compaction
compact_memory() {
    local frag_ratio=$(check_memory_fragmentation)
    
    # Compact if fragmentation ratio > 50
    if [ "$frag_ratio" -gt 50 ]; then
        echo 1 > /proc/sys/vm/compact_memory 2>/dev/null
        echo "$(date '+%Y-%m-%d %H:%M:%S'): Memory compacted (frag ratio: $frag_ratio)" >> "$LOG"
        
        # Show notification for significant compaction
        if [ "$frag_ratio" -gt 100 ]; then
            send_notification "Memory Optimized" "High fragmentation detected and fixed (ratio: $frag_ratio)" 1 "imm_compact"
        fi
        return 0
    fi
    return 1
}

# Get current running apps
get_running_apps() {
    dumpsys activity activities | grep -E "Hist #|Intent" | \
    grep -v "com.android.systemui" | \
    awk '/Intent/ {print $4}' | cut -d'/' -f1 | sort | uniq
}

# Record app usage pattern
record_app_pattern() {
    local current_hour=$(date '+%H')
    local current_day=$(date '+%u')  # 1=Monday, 7=Sunday
    local running_apps=$(get_running_apps)
    
    # Simple pattern recording (hour:day:apps)
    echo "$current_hour:$current_day:$running_apps" >> "$PATTERN_DB"
    
    # Keep only last 1000 entries to prevent DB bloat
    tail -1000 "$PATTERN_DB" > "$PATTERN_DB.tmp" 2>/dev/null
    mv "$PATTERN_DB.tmp" "$PATTERN_DB" 2>/dev/null
}

# Predict next apps based on patterns
predict_next_apps() {
    local current_hour=$(date '+%H')
    local current_day=$(date '+%u')
    
    if [ ! -f "$PATTERN_DB" ]; then
        return 1
    fi
    
    # Find similar time patterns (±1 hour, same day)
    local similar_patterns=$(grep -E "^($((current_hour-1))|$current_hour|$((current_hour+1))):$current_day:" "$PATTERN_DB" 2>/dev/null)
    
    if [ -n "$similar_patterns" ]; then
        # Extract most frequent apps from similar patterns
        echo "$similar_patterns" | cut -d':' -f3- | tr ' ' '\n' | sort | uniq -c | sort -nr | head -3 | awk '{print $2}'
    fi
}

# Preload predicted apps (warm start)
preload_apps() {
    local predicted_apps=$(predict_next_apps)
    local preload_count=0
    
    if [ -n "$predicted_apps" ]; then
        echo "$predicted_apps" | while read -r app; do
            if [ -n "$app" ] && [ "$app" != "null" ]; then
                # Use am start with STOP flag to preload without showing
                am start -W -S "$app/.MainActivity" >/dev/null 2>&1
                sleep 0.5
                am force-stop "$app" >/dev/null 2>&1
                echo "$(date '+%Y-%m-%d %H:%M:%S'): Preloaded $app" >> "$LOG"
                preload_count=$((preload_count + 1))
            fi
        done
        
        # Notification for preloading activity
        if [ "$preload_count" -gt 0 ]; then
            send_notification "Apps Preloaded" "Preloaded $preload_count apps based on usage patterns" 0 "imm_preload"
        fi
    fi
}

# Kill unused background apps
kill_unused_apps() {
    local predicted_apps=$(predict_next_apps)
    local running_apps=$(get_running_apps)
    local killed_count=0
    local killed_apps=""
    
    # Get apps that are running but not predicted
    echo "$running_apps" | while read -r app; do
        if [ -n "$app" ]; then
            # Skip system apps and predicted apps
            case "$app" in
                com.android.*|com.google.*|android) continue ;;
            esac
            
            # Check if app is in predicted list
            local is_predicted=$(echo "$predicted_apps" | grep -c "^$app$")
            
            if [ "$is_predicted" -eq 0 ]; then
                # Get app's last activity time
                local last_activity=$(dumpsys usagestats | grep "$app" | tail -1 | awk '{print $3}')
                local current_time=$(date +%s000)  # milliseconds
                
                # Kill if inactive for more than 10 minutes (600000ms)
                if [ -n "$last_activity" ] && [ $((current_time - last_activity)) -gt 600000 ]; then
                    am force-stop "$app" >/dev/null 2>&1
                    echo "$(date '+%Y-%m-%d %H:%M:%S'): Killed unused app: $app" >> "$LOG"
                    killed_count=$((killed_count + 1))
                    killed_apps="$killed_apps $(echo $app | cut -d'.' -f3-)"
                fi
            fi
        fi
    done
    
    # Show notification if killed multiple apps
    if [ "$killed_count" -gt 2 ]; then
        send_notification "Background Cleanup" "Closed $killed_count unused apps:$killed_apps" 1 "imm_cleanup"
    fi
}

# Check if screen is on
is_screen_on() {
    local screen_state=$(dumpsys power | grep "Display Power" | awk '{print $3}')
    [ "$screen_state" = "ON" ]
}

# Adaptive memory management based on screen state
adaptive_memory_management() {
    if is_screen_on; then
        # Screen ON: focus on responsiveness
        # More aggressive compaction for better performance
        compact_memory
        preload_apps
    else
        # Screen OFF: focus on battery savings
        # Less frequent compaction, more aggressive app killing
        kill_unused_apps
        
        # Compact memory every 5 cycles when screen off
        local cycle_count=$(cat "$DATAPATH/cycle_count" 2>/dev/null || echo "0")
        cycle_count=$((cycle_count + 1))
        echo "$cycle_count" > "$DATAPATH/cycle_count"
        
        if [ $((cycle_count % 5)) -eq 0 ]; then
            compact_memory
        fi
    fi
}

# Performance monitoring
monitor_performance() {
    local meminfo=$(cat /proc/meminfo)
    local mem_available=$(echo "$meminfo" | grep "MemAvailable" | awk '{print $2}')
    local mem_free=$(echo "$meminfo" | grep "MemFree" | awk '{print $2}')
    local mem_available_mb=$((mem_available / 1024))
    
    # Check for low memory condition
    if [ "$mem_available_mb" -lt 500 ]; then
        send_notification "⚠️ Low Memory Alert" "Only ${mem_available_mb}MB available - Optimizing memory now..." 2 "imm_lowmem"
        # Force memory compaction on low memory
        echo 1 > /proc/sys/vm/compact_memory 2>/dev/null
        echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
    fi
    
    # Log performance metrics every hour
    local last_log_hour=$(cat "$DATAPATH/last_log_hour" 2>/dev/null || echo "0")
    local current_hour=$(date '+%H')
    
    if [ "$current_hour" != "$last_log_hour" ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S'): MemAvailable: ${mem_available}kB, MemFree: ${mem_free}kB" >> "$LOG"
        echo "$current_hour" > "$DATAPATH/last_log_hour"
        
        # Hourly performance report
        local mem_used_mb=$((($(grep "MemTotal" /proc/meminfo | awk '{print $2}') - mem_available) / 1024))
        send_notification "📊 Memory Status" "Available: ${mem_available_mb}MB | Used: ${mem_used_mb}MB" 0 "imm_hourly"
    fi
}

# Daily learning report
daily_report() {
    local last_report_day=$(cat "$DATAPATH/last_report_day" 2>/dev/null || echo "0")
    local current_day=$(date '+%j')  # Day of year
    
    if [ "$current_day" != "$last_report_day" ]; then
        local pattern_count=$(wc -l < "$PATTERN_DB" 2>/dev/null || echo "0")
        local unique_apps=$(cut -d':' -f3- "$PATTERN_DB" 2>/dev/null | tr ' ' '\n' | sort | uniq | wc -l)
        
        send_notification "🧠 Learning Report" "Analyzed $pattern_count usage patterns across $unique_apps apps" 0 "imm_daily"
        echo "$current_day" > "$DATAPATH/last_report_day"
    fi
}

# Main execution loop
main_loop() {
    local cycle=0
    
    while true; do
        cycle=$((cycle + 1))
        
        # Record usage patterns every cycle
        record_app_pattern
        
        # Performance monitoring
        monitor_performance
        
        # Daily learning report
        daily_report
        
        # Adaptive management every 30 seconds
        if [ $((cycle % 1)) -eq 0 ]; then
            adaptive_memory_management
        fi
        
        # Clean up logs if too large (>1MB)
        if [ -f "$LOG" ]; then
            local log_size=$(stat -f%z "$LOG" 2>/dev/null || stat -c%s "$LOG" 2>/dev/null)
            if [ "$log_size" -gt 1048576 ]; then
                tail -500 "$LOG" > "$LOG.tmp"
                mv "$LOG.tmp" "$LOG"
            fi
        fi
        
        # Wait 30 seconds between cycles
        sleep 30
    done
}

# Cleanup function for graceful shutdown
cleanup() {
    echo "$(date '+%Y-%m-%d %H:%M:%S'): IMM Service Stopped" >> "$LOG"
    send_notification "IMM Service Stopped" "Intelligent Memory Manager has been disabled" 0 "imm_shutdown"
    exit 0
}

# Trap signals for cleanup
trap cleanup TERM INT

# Initialize and start main loop
init_logging
echo "$(date '+%Y-%m-%d %H:%M:%S'): Starting main loop..." >> "$LOG"

# Run main loop in background
main_loop &

# Keep script running
wait